shimmer
=======

ROS shimmer interface
